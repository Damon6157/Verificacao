# Oauth2-Script-Bot-2022
Oauth2-Script-Bot Public Oauth2 Discord Bot script with guild.join, cmd : help, users, links, joinall, wl list, wl add, wl remove,Bot discord auth edit and inspire from ytzmo auth bot Create By Ξl K4lash#9999





Install Requirements

npm install
