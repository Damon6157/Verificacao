module.exports = {
    token: "TOKEN-DO-BOT",
    id: "ID-DO-BOT",
    secret: "CLIENT-SECRET",
    webhook: "WEBHOOK-LINK",
    prefix: ";",
    owners: [""],
    authLink: "https://discord.com/api/oauth2/authorize?client_id=ID-DO-BOT&redirect_uri=LINK-AQUI&response_type=code&scope=identify%20guilds.join",

}
